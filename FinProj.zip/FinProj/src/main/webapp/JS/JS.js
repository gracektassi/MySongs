

function saveCookie(name,value,days) {
    var date, expires;
    if (days) {
        date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        expires = "; expires=" + date.toGMTString();
            }else{
        expires = "";
    }
    document.cookie = name + "=" + value + expires + "; path=/";
}



function readCookie(name) {
    var i, c, ca, nameEQ = name + "=";
    ca = document.cookie.split(';');
    for(i=0;i < ca.length;i++) {
        c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1,c.length);
        }
        if (c.indexOf(nameEQ) == 0) {
            return c.substring(nameEQ.length,c.length);
        }
    }
    return '';
}


function AskUserID(){



   var ID =prompt("Enter ID to continue");

localStorage.setItem('IDNUMBER',ID);

var CLASS =prompt("Enter Class to continue");

localStorage.setItem('CLASS',ID);

var PERIOD =prompt("Enter PERIOD to continue");

localStorage.setItem('PERIOD',ID);

if(ID!=''&&CLASS!=''&&PERIOD!=''&&CLASS&&PERIOD){
    window.location.href = "page2.php?ID="+ID+"&CLASS="+CLASS+"&PERIOD="+PERIOD;
}
else  alert("Please enter all correct values");
//alert(localStorage.getItem('lastname'));



}


function AskClassID(){



   
    var CLASS =prompt("Enter Class to continue");
    
    
    
    var PERIOD =prompt("Enter PERIOD to continue");
    
    
    
    if(CLASS!=''&&PERIOD!=''&&CLASS&&PERIOD){
        window.location.href = "page3.php?CLASS="+CLASS+"&PERIOD="+PERIOD;
    }
    else  alert("Please enter  all correct values");
    //alert(localStorage.getItem('lastname'));
    
    
 
 
 //alert(localStorage.getItem('lastname'));
 
 
 
 }

 function AllClasses(){



   
    
    var PERIOD =prompt("Enter PERIOD to continue");
    

    
    if(PERIOD!=''&&PERIOD){
        //window.location.href = "page3.php?CLASS="+CLASS+"&PERIOD="+PERIOD;
        window.open("AllClasses.php?PERIOD="+PERIOD);
       
   
    }
    else  alert("Please enter  all correct values");
    //alert(localStorage.getItem('lastname'));
    
    
 
 
 //alert(localStorage.getItem('lastname'));
 
 
 
 }

 


 function Disp(){

    alert("Please enter  correct values");


 }

 
 function Err(){

    alert("There was a problem");


 }
 


 function goBack() {
    window.history.back();
 }


 function FakePass(){

alert ("Either your password or ID is incorrect, try again");
goBack();

 }



$(function() {

  $("#dialog").dialog({
     autoOpen: false,
     modal: true
   });

  $("#myButton").on("click", function(e) {
      e.preventDefault();
      $("#dialog").dialog("open");
  });

});



function toggleMenu(){
   
  //  alert("Hello");
  let subMenu=document.getElementById("SubMenu");

subMenu.classList.toggle("open-menu");

}

function finSaveFunc() {
  var stName = document.getElementById("stName")
  var Subject = document.getElementById("Subject")
  var Grade = document.getElementById("Grade")
  var newForm = document
    .getElementById("form2")
    .appendChild(stName)
    .appendChild(Subject)
    .appendChild(Grade);
  newForm.submit();
}



  $(document).ready(function(){
            	$('#check').on('click', function(){
            		
            		var value = "A";
                    $.get("data.jsp",{q:value},function(data){
                   //  $("#javaquery").html(data);
                     
            	});
            	})
            	
            	var param=document.getElementById('users').value;
            	 var value = param;
            	
            	$('#check').click({param1:param},cool_function);  
            	
            	function cool_function(event){
            		
            		alert(event.data.param1);
            		
            	}
            	
                 $("#users").change(function(){
                    // var value = $(this).val();
                    
                    var param=document.getElementById('users').value;
            	 var value = param;
            	
                     $.get("data.jsp",{q:value},function(data){
                      $("#javaquery").html(data);
                     });
                 });
             });




function SubmitUsers(IdGr, GroupName){
	

	   var AddUsers=document.getElementById('AddUsers').value;
            
	if(AddUsers=="Personnal")	{
		var UserName=prompt("Enter the Id UserName");
		
		if(UserName.length<5){alert("Please enter a valide UserName"); return ;}
		
		if(window.confirm("The Action cannot be undone. Continue?"))
		
		 window.location.href = "AddingPeople?IdGr="+IdGr+"&GroupName="+GroupName+"&UserName="+UserName ;

	}
	else{
			if(window.confirm("The Action cannot be undone. Continue?"))
	
		 window.location.href = "AddingPeople?IdGr="+IdGr+"&GroupName="+GroupName+"&AddUsers="+AddUsers ;

	} 
 	
	
	
}


function CopyLink(textCopy,GroupName){
	
	/*
	var textCopy=document.getElementById('CopyLink');
	textCopy.select();
	textCopy.setSelectionRange(0,99999);
	*/
	
	navigator.clipboard.writeText(textCopy);
	
	alert("Link copied to cliboard");
	window.location.href="InvitePeople.jsp?JoinLink="+textCopy+"&GroupName="+GroupName;
	
}

