package FinProj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateUserGroup {

	
	
	public UpdateUserGroup(){
		
		

	    
	    
		
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		Connection con=null;
		
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
			
		}
		
		
		
		
		
		try
{
con.setAutoCommit(false);






//1 or more queries or updates

	PreparedStatement ps2=con.prepareStatement("UPDATE USER_GROUPS SET UserName=? WHERE UserName=?");


	ps2.setString(4, "Admin");
	
			
	int number2 =ps2.executeUpdate();


con.commit();


con.setAutoCommit(true);
		
		
		
	
	}
		catch(Exception ex) {}
		
	
	
}
}
	
	
	

