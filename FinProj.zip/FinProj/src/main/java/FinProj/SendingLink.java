package FinProj;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Servlet implementation class SignUpServlet
 */
@MultipartConfig(fileSizeThreshold = 1024 * 1024 *10,
maxFileSize = 1024 * 1024 * 50, 
maxRequestSize = 1024 * 1024 * 5 * 50)


public class SendingLink extends HttpServlet {
   String UPLOAD_DIRECTORY="SSMPFILES";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendingLink() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();
		   DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");  
		   String time=dtf.format(now);
		   String timeFile=dtf2.format(now);
			

		   
		
		   String fileName="";
		   String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
		   String MediaMessage="";
		  	
		   try {
		   
		   File uploadDir = new File(uploadPath);
		   if (!uploadDir.exists()) uploadDir.mkdir();
		 	
		   	

		   for (Part part : request.getParts()) {
		       fileName = part.getSubmittedFileName();
		       part.write(uploadPath + File.separator +time+ fileName);
		       
		    if(fileName!=null&&fileName.length()>1)   MediaMessage+=ElementValues.GetTypeString(fileName,timeFile);
		   }
		   }
		   catch(Exception ex) {
			   ex.printStackTrace();
			   
		   }

			String Media=MediaMessage;
			
			
		   
		   
		   
		   
		   
		   
		 	HttpSession session=request.getSession(true);
			
		   treatEl ident=(treatEl)session.getAttribute("Ident");


 
 //  treatEl identk=(treatEl)session.getAttribute("Ident");
 //  PrintWriter wrk=response.getWriter();
	
  // wrk.println(identk.Names);

		   
		String Message=(String) session.getAttribute("MessageLink");
		String Id_Message=ident.Sender_Id+time.replace("/", "").replace(" ", "");
	
		String Sender_Id=ident.Sender_Id;
		String TimeSent=time;
		String Group_receiver="";
		
		String sentFrom=request.getParameter("SentFrom");
		
		String AfterSend="Home.jsp";
		
		if(sentFrom.equals("Broadcast")) {
			
		
			Group_receiver=request.getParameter("Year")+"X"+request.getParameter("Department");
			
		}
		else if (sentFrom.equals("Unicast")) {
			Group_receiver=request.getParameter("GroupId");
			AfterSend="LiveChat.jsp?IdGr="+ Group_receiver;
		}
		
		
		String Readable="1";
		
		

		

	
	
	
       
       
     
       
       
       
       
	
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		Connection con=null;
		
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
			
		}
		
		
		
		
		
		try
{
  con.setAutoCommit(false);

  
  
  
  
  
   //1 or more queries or updates

  PreparedStatement ps=con.prepareStatement("INSERT INTO Messages ( Message,Id_Message, Sender_Id, Group_receiver,Readable, MediaMessage) values (?,?,?,?,?,?)");
	ps.setString(1, Message);
	ps.setString(2, Id_Message);
	ps.setString(3, Sender_Id);
	
	ps.setString(4, Group_receiver);
	ps.setString(5, Readable);
	ps.setString(6, Media);
	
	
			
	int number =ps.executeUpdate();
  


  
   con.commit();
   
   
   con.setAutoCommit(true);
 //  request.setAttribute("Names","${student.Names}" );

request.getSession().setAttribute("Password", request.getParameter("Password"));

//RequestDispatcher rd=request.getRequestDispatcher("beforeLogin.jsp");
//rd.forward(request, response);
response.getWriter().append("OKEY at: ").append(request.getContextPath());


RequestDispatcher rd=request.getRequestDispatcher(AfterSend);
rd.forward(request, response);
   
}
catch(Exception e)
{
	e.printStackTrace();
	PrintWriter wr=response.getWriter();
	
	wr.println("<p>"+dtf.format(now)+"</p>");
	wr.println("<p style=\"color:red\"> There was a problem while sending your messages  Restart <a href=\"Home.jsp\">here</a>" +  e.getMessage()+  "</p>");

	
   try {
	con.rollback();
} catch (SQLException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
   
   
}
finally
{
	
	
   try {
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
   
   
}
		
	

		
	
	
		
		
	
	
	
	
	
	
	

	
	
	
	
	doGet(request, response);
	
	}
	

	
	
	

}
