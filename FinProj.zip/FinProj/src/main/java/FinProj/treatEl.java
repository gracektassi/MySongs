package FinProj;

public class treatEl {
	
	public String Department="";
	public String Names="";
	public String Email="";
	public String Tel="";
	public String Address="";
	public String Year="";
	public String Category="";
	public String Password="";
	public String Pseudo="";
	public String NE="";
	public String DateIdentity="";
	public String Message="";
	public String PhotosNews="";
	public String AudiosNews="";
	public String VideosNews="";
	public String FilesNews="";
	public String DateNews="";
	public String ChurchTitleDescr="";
	public String TextsDescr="";
	public String ImagesDescr="";
	public String AudiosDescr="";
	
	public String VideosDescr="";
	public String FilesDescr="";
	public String DateDescr="";
	public String State=""; 
	public String AvailableTo=""; 
	
	public String Id_Message="";
	public String Sender_Id="";
	public String TimeSent="";
	public String Group_receiver="";
	public String Readable="";
	public String Type="",
	
	    Group_Id="",
		Group_Name="",
	    Group_Creator="",
	    Group_Join_Link="",
	    Date_Created="",
	    Status="";
		

		

	
	
public String getName() {
	
	return Names;
}
	
	

public treatEl(String Names,String Email,String Tel, String Address,String Category, String Password, String Pseudo, String NE, String Date,String State, String AvailableTo) {
	
	
	this.State=State;
	this.AvailableTo=AvailableTo;
	
	this.Names=Names;
	this.Tel=Tel;
	this.Email=Email;
	this.Password=Password;
	this.Address=Address;
	this.Category=Category;
	this.Pseudo=Pseudo;
	this.NE=NE;
	this.DateIdentity=Date;
	
	
}

	


public treatEl(String Names,String Email, String Category, String Password, String Pseudo, String Date) {
	
	
	
	
	this.Names=Names;
	this.Email=Email;
    this.Password=Password;
	this.Category=Category;
	this.Pseudo=Pseudo;
	this.DateIdentity=Date;
	
	
}
	
	
	
	public treatEl(String Names,String Email,String Tel, String Address,String Category, String Password, String Pseudo, String NE, String Date) {
		
		
		
		
		this.Names=Names;
		this.Tel=Tel;
		this.Email=Email;
		this.Password=Password;
		this.Address=Address;
		this.Category=Category;
		this.Pseudo=Pseudo;
		this.NE=NE;
		this.DateIdentity=Date;
		
		
	}
	
	
	
public treatEl(String Email,String Message, String Photos,String Audios, String Videos, String Files, String Date) {
		
		
		
		this.Email=Email;
		this.Message=Message;
		this.PhotosNews=Photos;
		this.AudiosNews=Audios;
		this.VideosNews=Videos;
		this.FilesNews=Files;
		this.DateNews=Date;
		
		
	}
	
	
	
public treatEl(String ChurchTitle,String Text, String Images,String Audios, String Videos, String Files, String Date,int i) {
	
	
	
	this.ChurchTitleDescr=ChurchTitle;
	this.TextsDescr=Text;
	this.ImagesDescr=Images;
	this.AudiosDescr=Audios;
	this.VideosDescr=Videos;
	this.FilesDescr=Files;
	this.DateDescr=Date;
	
	
}



public treatEl(String Email,String State, String AvailableTo) {



this.Email=Email;
this.State=State;
this.AvailableTo=AvailableTo;


}



public treatEl(String names2, String email2, String pass1, String year2, String tel2, String department2,  String category2, 
		 String date) {
	
	
	// TODO Auto-generated constructor stub
	
	this.Names=names2;
	this.Email=email2;
	Sender_Id=Email;
	this.Tel=tel2;
	this.Year=year2;
	this.Category=category2;
	this.Password=pass1;
	this.Department=department2;
	this.DateIdentity=date;
	
	
}



public treatEl(int digit,String Message_In, String Id_Message_In,String Sender_Id_In, String TimeSent_In, String Group_receiver_In, String Readable_In, String Type_In) {
	
	
    Message=Message_In;
    Id_Message=Id_Message_In;
    Sender_Id=Sender_Id_In;
	TimeSent=TimeSent_In;
    Group_receiver=Group_receiver_In;
	Readable=Readable_In;
	Type=Type_In;
	
	
	
	
}


public treatEl(int digit, String GroupName, String GroupCreator, String JoinLink,String Group_Ids,String CreatedTime) {
	
    Group_Id=Group_Ids;
	Group_Name=GroupName;
    Group_Creator=GroupCreator;
    Group_Join_Link=JoinLink;
    Date_Created=CreatedTime;
	
	
	
	
}

public treatEl(int digit, String UserId,String MStatus) {


	Sender_Id=UserId;
	Status=MStatus;
	State=Status;
		
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


}
