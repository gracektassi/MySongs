package FinProj;
import java.sql.*;

public class sqlManager {

	private treatEl ident;
	
	public sqlManager(String query,int i) throws SQLException {
		
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection con = DriverManager.getConnection(url, username, password);
		Statement st=con.createStatement();
		String requ=query;
		
		
		
		
		

		ResultSet rs=st.executeQuery(requ);
		rs.next();
		
		if(i==0) {

			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6)
					
					);

					}
		

		if(i==1) {

this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7),rs.getString(8),
		rs.getString(9)
		
		);

		}


		
		
		
		

		if(i==2) {

this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7)
		);

		}
		if(i==20) {

			this.ident=new treatEl(2, rs.getString(1),rs.getString(2)
					
					);

					}
		
		
		
		if(i==3) {

			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6),
					rs.getString(7),1
					);

					}
		
		if(i==8) {// If 

			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6),
					rs.getString(7),rs.getString(8)
					);

					}
		
		if(i==9) {// If 

			this.ident=new treatEl(9, rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5)

					);

					}
		
		
		
	}
	
	
	
	public treatEl getIdent() {
		
		
		return this.ident;
	}
	
	
	
}
