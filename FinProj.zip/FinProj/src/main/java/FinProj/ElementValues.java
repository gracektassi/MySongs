package FinProj;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ElementValues {
	
	public static ArrayList<String> Departments;//=new ArrayList<String>();
	public static ArrayList<String> Details;
	public static ArrayList<String> Medias;
	public static String UPLOAD_DIRECTORY="SSMPFILES";
	public ElementValues() {
		
		
		Departments=new ArrayList<String>();
		Departments.add("Computer Science");
		Departments.add("Law");
		Departments.add("Social Science");
		Departments.add("Economics");
		Departments.add("Other");
		Boolean admin=true;
		
		Details=new ArrayList<String>();
		Medias=new ArrayList<String>();
		
		Medias.add("Attach Video");
		Medias.add("Attach pictures");
		Medias.add("Attach File");
		Medias.add("Attach other");
		
		//admin
		if(admin) {
		Details.add("Delete Message");
		Details.add("Block Sender");
		Details.add("Views");
		Details.add("Make this As Admin");
	
		}
		else {
			//admin
			if(true) {
			Details.add("Delete Message");
			Details.add("Message Sender");
			Details.add("Views");
			}
			
			
			
		}
		
		
	}
	
	
	public static String GetTypeString(String MyFile) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");  
		   LocalDateTime now = LocalDateTime.now();
		   String time=dtf.format(now);
			
		String FileP= UPLOAD_DIRECTORY+File.separator+time+MyFile;
		
		
		String FileType="";
		String htmls="";
		String FileParts[]=FileP.split("[.]",0);
	  if(FileParts.length>0)	FileType=FileParts[FileParts.length-1];
	  

		if(FileType.toLowerCase().equals("gif")||FileType.toLowerCase().equals("jpg")||FileType.toLowerCase().equals("jpeg")||FileType.toLowerCase().equals("gif")||FileType.toLowerCase().equals("png"))
		{
			
		htmls="<img src=\""+FileP+"\" class=\"ImageMessage\"/>";
			
		}
		
		else if (FileType.toLowerCase().equals("mp4"))
			
		{
		
			 htmls="<video controls=\"controls\" preload=\"auto\" width=\"380px\" >"
				 		
			 +"<src=\""+FileP+"\"/></video>"
			 ;
			
		}
   else if (FileType.toLowerCase().equals("mp3")||FileType.toLowerCase().equals("MP3")||FileType.toLowerCase().equals("wav")||FileType.toLowerCase().equals("WAV"))
			
		{
		
	 htmls="<audio  controls=\"controler_audio\" autoplay=\"autoplay\" preload=\"auto\" >"
	 		
			 +"<source=\""+FileP+"\"/></audio>"
			 ;	
			
		}
		
		else {
			
			htmls="<a href=\""+FileP+"\">"+MyFile+"</a>";
		}
		return htmls+"<br>";
	}
	
	
	
	
	public static String GetTypeString(String MyFile,String times) {
			
		String FileP= UPLOAD_DIRECTORY+File.separator+times+MyFile.replace(" ", "_");
		
		
		String FileType="";
		String htmls="";
		String FileParts[]=FileP.split("[.]",0);
	  if(FileParts.length>0)	FileType=FileParts[FileParts.length-1];
	  

		if(FileType.toLowerCase().equals("gif")||FileType.toLowerCase().equals("jpg")||FileType.toLowerCase().equals("jpeg")||FileType.toLowerCase().equals("gif")||FileType.toLowerCase().equals("png"))
		{
			
		htmls="<img src=\""+FileP+"\" class=\"ImageMessage\"/>";
			
		}
		
       else if (FileType.toLowerCase().equals("mp4"))
			
		{
			
			 htmls="<video controls=\"controls\" preload=\"auto\"  poster=\"Images/logo.png\" width=\"380px\">\r\n"
			 		+ "<source src=\""+FileP+"\"/>\r\n"
			 		+ "\r\n"
			 		+ "</video>"
			 ;
			
		}
   else if (FileType.toLowerCase().equals("mp3")||FileType.toLowerCase().equals("MP3")||FileType.toLowerCase().equals("wav")||FileType.toLowerCase().equals("WAV"))
			
		{
		
	 htmls="<audio controls> <source src=\""+FileP+"\" type=\"audio/mpeg\">	Your browser does not support the audio element.</audio>	";
			
		}
		
		else {
			
			htmls="<a href=\""+FileP+"\">"+MyFile+"</a>";
		}
		return htmls+"<br>";
	}
	
	
	public static String  CheckLinksLines(String Message0) {
		
		
		String Message=Message0.replace(System.getProperty("line.separator"), "<br>");
		
		if(Message.contains(".com")||Message.contains(".org")||Message.contains("http")) {
		 String spl[]=Message.split(" ");
		 Message="";
		 
		 for(int i=0;i<spl.length;i++) {
			 
			 if(spl[i].contains(".com")||spl[i].contains(".org")||spl[i].contains("http")) 
				 Message+="<a href=\""+spl[i]+"\" >"+spl[i]+" </a>";
			 else
			 Message+=spl[i]+" ";
		 }
			
			
		}
		
		return Message;
		
		
	}
	
	
	
	
	
	

}
