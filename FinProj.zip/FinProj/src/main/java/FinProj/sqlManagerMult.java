package FinProj;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class sqlManagerMult {

	private treatEl ident;
	private List <treatEl> identList=new ArrayList<>();;
	private ResultSet results=null;
	
	
	
	
	
	public sqlManagerMult(String query,int i) throws SQLException {
		
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection con = DriverManager.getConnection(url, username, password);
		
		
		PreparedStatement stmt=con.prepareStatement(query);  
		 
		
		ResultSet rs=stmt.executeQuery(); 
		 
	//	System.out.println(res.getInt(1)+" "+res.getString(2));  
		
			
		//rs.next();
		
		

	
		
		if(i==0) {
			while(rs.next()){ 
			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6)
					
					);
			
			identList.add(this.ident);

					}
		}
		
		if(i==8) {
			while(rs.next()){ 
this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7),rs.getString(8)
		
		);
identList.add(this.ident);

			}
		}


		if(i==1) {
			while(rs.next()){ 
this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7),rs.getString(8),
		rs.getString(9)
		
		);
identList.add(this.ident);

			}
		}


		
		
		
		

		if(i==2) {
			while(rs.next()){
this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7)
		);

identList.add(this.ident);

			}

		}
		
		
		
		if(i==3) {
			while(rs.next()){
			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6),
					rs.getString(7),1
					);

			identList.add(this.ident);

		}
			
					}
		

		
		if(i==4) {
			while(rs.next()){
			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3)
					);

			identList.add(this.ident);

		}
			
		
			if(i==5) {
				this.results=rs;
				while(rs.next()){
					this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6),
					rs.getString(7),rs.getString(8),
					rs.getString(9),rs.getString(10),rs.getString(11)
						);

				identList.add(this.ident);

			}
				
						}
		
		}
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public sqlManagerMult(String query,String param,int i) throws SQLException {
		
		String url="jdbc:mysql://localhost:3306/BD";
		String username="GRACE";
		String password="09876009T@ssi";
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection con = DriverManager.getConnection(url, username, password);
		
		
		PreparedStatement stmt=con.prepareStatement(query);  
		 
		stmt.setString(1,param);
		
		ResultSet rs=stmt.executeQuery(); 
		 
	//	System.out.println(res.getInt(1)+" "+res.getString(2));  
		
			
		//rs.next();
		
		

	
		
		if(i==0) {
			while(rs.next()){ 
			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6)
					
					);
			
			identList.add(ident);

					}
		}
		
		

		if(i==1) {
			while(rs.next()){ 
this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7),rs.getString(8),
		rs.getString(9)
		
		);
identList.add(ident);

			}
		}


		
		
		
		

		if(i==2) {
			while(rs.next()){
this.ident=new treatEl(rs.getString(1),rs.getString(2),
		rs.getString(3),rs.getString(4),
		rs.getString(5),rs.getString(6),
		rs.getString(7)
		);

identList.add(ident);

			}

		}
		
		
		
		if(i==3) {
			while(rs.next()){
			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),
					rs.getString(5),rs.getString(6),
					rs.getString(7),1
					);

			identList.add(ident);

		}
			
					}
		

		
		if(i==4) {
			while(rs.next()){
			this.ident=new treatEl(rs.getString(1),rs.getString(2),
					rs.getString(3)
					);

			identList.add(ident);

		}
			
					}
		
		
		
	}
	
	
	
	public treatEl getIdent() {
		
		
		return this.ident;
	}
	
public List<treatEl> getIdentList() {
		
		
		return this.identList;
	}


public ResultSet res() {
	return this.results;
}
	
	
}
