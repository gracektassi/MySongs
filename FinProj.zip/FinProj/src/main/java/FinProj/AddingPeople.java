package FinProj;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class AddingPeople
 */
public class AddingPeople extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddingPeople() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		Connection con=null;
		
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
			
		}
		
		
		
		
		
		try
{
con.setAutoCommit(false);

		
String GroupName=request.getParameter("GroupName");

String IdGr=request.getParameter("IdGr");

String User_Id=request.getParameter("UserName");


if(User_Id!=null) {

	try {
	
	
PreparedStatement ps2=con.prepareStatement("INSERT INTO USER_GROUPS (UserName,IdGr,NameGroup) VALUES (?,?,?)");
ps2.setString(1, User_Id);
ps2.setString(2, IdGr);
ps2.setString(3, GroupName);

		
int number2 =ps2.executeUpdate();

	} catch(Exception ex) {
		
		ex.printStackTrace();
		
	}


}	
	
else {
	
	String AddUsers=request.getParameter("AddUsers");
	
    String AddParts[]=AddUsers.split("X");
    String Depart=AddParts[0];
    String year=AddParts[1];
    
    sqlManagerMult sqlM = new sqlManagerMult("SELECT * FROM USERS WHERE Department='"+Depart+"' AND Year='"+year+"'",8);
	//	sqlM2 = new sqlManagerMult("SELECT * FROM MemberChar WHERE Email=? ",mail,4);

    for(treatEl User:sqlM.getIdentList()) {
    	
    try {	

PreparedStatement ps2=con.prepareStatement("INSERT INTO USER_GROUPS (UserName,IdGr,NameGroup) VALUES (?,?,?)");
ps2.setString(1, User.Sender_Id);
ps2.setString(2, IdGr);
ps2.setString(3, GroupName);
		
int number2 =ps2.executeUpdate();
con.commit();
con.setAutoCommit(true);


    }
    catch(Exception ex) {
    	ex.printStackTrace();
    	
    }
    
    	
    }
    
    
	
	
}

String AfterAdding="LiveChat.jsp?IdGr="+ IdGr;
RequestDispatcher rd=request.getRequestDispatcher(AfterAdding);
rd.forward(request, response);


	
}
	catch(Exception ex) {
		
		ex.printStackTrace();
		
		String IdGr=request.getParameter("IdGr");
String AfterAdding="LiveChat.jsp?IdGr="+ IdGr;
RequestDispatcher rd=request.getRequestDispatcher(AfterAdding);
rd.forward(request, response);

	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
