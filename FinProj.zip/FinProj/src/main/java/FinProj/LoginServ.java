package FinProj;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import smfPack.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet implementation class LoginServ
 */
public class LoginServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at Me: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */


	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		String mail=String.valueOf(request.getParameter("UserName"));
		session.setAttribute("Email", mail);
	//	session.setMaxInactiveInterval(20);
		
		String Pass=String.valueOf(request.getParameter("password"));
		sqlManager sqlM0 = null;
		
		try {
			
			sqlM0 = new sqlManager("SELECT * FROM USER_STATUS WHERE UserName='"+mail+"'",20);
			if(sqlM0.getIdent().Status.equals("0")) {
				
				RequestDispatcher rd=request.getRequestDispatcher("Login.jsp?Done=0");
				rd.forward(request, response);
				
				
			};
			
		}catch(Exception ex) {
			ex.printStackTrace();
			
		}
		
			//sqlManagerMult sqlM2 = null;
		
			sqlManager sqlM = null;
		try {
			
			sqlM = new sqlManager("SELECT * FROM USERS WHERE UserName='"+mail+"'",8);
		//	sqlM2 = new sqlManagerMult("SELECT * FROM MemberChar WHERE Email=? ",mail,4);
			
		//	treatEl ident2=sqlM2.getIdent();
	//		session.setAttribute("AvailableTo", ident2.AvailableTo);
			
	//		System.out.println("ME VOICI ENFIN "+ident2.AvailableTo);
			treatEl ident=sqlM.getIdent();
			String Password=ident.Password;
			Password=ManageContents.TranslateEncryptedString(Password, false);
			
			if(Pass.equals(Password)) {
			
			session.setAttribute("GenTitle", "SSMP");
			session.setAttribute("Site", "SSMP");
			
			session.setAttribute("titlegen", "SSMP");
			session.setAttribute("Ident", ident);
			
	//		session.setAttribute("EmailIdent2", ident2);
			
			
			RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
			rd.forward(request, response);
			}
			
			else {
				
				PrintWriter pw=response.getWriter();
				String mess="<br>Restart <a href=\"Login.jsp\"> here</a>";
				pw.println("<p style=\"color:red;\">Please write the right password for "+mail+mess+"    </p>");
					
			}
			
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			PrintWriter pw=response.getWriter();
			String mess="<br> Restart <a href=\"Login.jsp\"> here</a>";
			
			pw.println("<p style=\"color:red;\">Please make sure your  Identification is well done "+mail+mess+"</p>");
			
		
		}
		
		doGet(request, response);
	}

	
	
	
	
	

}
