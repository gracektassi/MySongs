package FinProj;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import smfPack.ManageContents;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Servlet implementation class SignUpServlet
 */
public class Advanced extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Advanced() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   System.out.println(dtf.format(now));
		   String CategoryNow=request.getParameter("CategoryNow");
		   HttpSession session=request.getSession(true);
		   
		   
		   
		
		String pass1=request.getParameter("Password");
		String pass2=request.getParameter("Password2");
		
		String Names=request.getParameter("Names");
		String Email=request.getParameter("Email");
		String Tel=request.getParameter("Tel");
		String Year=request.getParameter("Year");
		String Category=request.getParameter("Category");
		String Department=request.getParameter("Department");
		String Status="1";
		
		if((!CategoryNow.equals("Admin"))&&(!Email.equals(session.getAttribute("Email")))) {
			
			
			
			RequestDispatcher rd=request.getRequestDispatcher("Home.jsp?Done=0");
			rd.forward(request, response);
			
			return;
		};
		
		
		
		if(request.getParameter("Status")!=null) {
			Status="1";
		}
		else Status="0";
		
		String Date=dtf.format(now);
		
		

		
		
		
		treatEl ident=new treatEl(Names,Email, Tel, Year, Category, pass1, Department, Date);
		
	if(pass1.equals(pass2)&&pass1.length()>3) {
		
		pass1=ManageContents.GetEncryptedString(pass1, false);
		
		
       String hidstate=request.getParameter("hidstate");
       request.setAttribute("hidstate", hidstate);
     	request.setAttribute("ident", ident);
     	
     	java.sql.Date sqlDate = new java.sql.Date(new java.util.Date().getTime());
		
     	
     	
     	
       request.setAttribute("sqlDate", sqlDate);
       
       
  /*     
   	RequestDispatcher rd=request.getRequestDispatcher("tablesdb.jsp");
	rd.forward(request, response);
	doGet(request, response);
	*/
	
	
	
	
       
       
     
       
       
       
       
	
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		Connection con=null;
		
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
			
		}
		
		
		
		
		
		try
{
  con.setAutoCommit(false);

  
  
  
  
  
   //1 or more queries or updates
  PreparedStatement del=con.prepareStatement("DELETE FROM User_Status WHERE UserName=?");
	del.setString(1, Email);
	 PreparedStatement del1=con.prepareStatement("DELETE FROM Users WHERE UserName=?");
		del1.setString(1, Email);

  PreparedStatement ps0=con.prepareStatement("INSERT INTO User_Status ( UserName,Status) VALUES (?,?)");
 	ps0.setString(1, Email);
 	ps0.setString(2, Status);
  PreparedStatement ps=con.prepareStatement("INSERT INTO Users ( Names,UserName, Password,Year,Tel , Department, Category,LastSeen) VALUES (?,?,?,?,?,?,?,?)");
	ps.setString(1, Names);
	ps.setString(2, Email);
	ps.setString(3, pass1);
	ps.setString(4, Year);
	ps.setString(5, Tel);
	ps.setString(6, Department);
	ps.setString(7, Category);
	ps.setString(8, Date);
	
	
	del.executeUpdate();
	del1.executeUpdate();
	ps0.executeUpdate();
	int number =ps.executeUpdate();
  


  
   con.commit();
   
   
   con.setAutoCommit(true);
 //  request.setAttribute("Names","${student.Names}" );

request.getSession().setAttribute("Password", request.getParameter("Password"));
response.getWriter().append("OKEY at: ").append(request.getContextPath());

PrintWriter wr=response.getWriter();
wr.println("<p><script>alert(\"Successifully saved\")</script></p>");


RequestDispatcher rd=request.getRequestDispatcher("Home.jsp?Done=1");
rd.forward(request, response);

   
}
catch(Exception e)
{
	e.printStackTrace();
	PrintWriter wr=response.getWriter();
	wr.println("<p>"+e.getMessage()+"</p>");

	wr.println("<p>"+dtf.format(now)+"</p>");
	wr.println("<p style=\"color:red\"><script src=\"JS/JS.js\"></script>\r\n"
			+ "  There was a problem while registration  Restart <strong onclick=\"goBack()\" > here</strong>  </p>");

	
	
   try {
	con.rollback();
} catch (SQLException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
   
   
}
finally
{
	
	
   try {
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
   
   
}
		
	

		
	
	}
		
		
	
	
	
	
	
	
	
	
	else {
		
		PrintWriter wr=response.getWriter();
		wr.println("<p>"+dtf.format(now)+"</p>");
		wr.println("<p style=\"color:red\"> There was a problem while registration: check also Your passwords, both must match: Restart <a href=\"Advanced.jsp\">here</a>  </p>");
				
		
	}
	
	
	
	
	doGet(request, response);
	
	}

}
