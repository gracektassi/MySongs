package FinProj;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Servlet implementation class CreateGroup
 */
public class CreateChat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateChat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   System.out.println(dtf.format(now));
		
		HttpSession session=request.getSession(true);
		
		String UserName=request.getParameter("UserName");
		String UName=request.getParameter("Name");
		
		treatEl Creator=(treatEl)session.getAttribute("Ident");
		
		
		
		String GroupName=request.getParameter("Name");
		
		
		String IdGr=dtf.format(now)+Creator.Sender_Id;
		
		String Creator_Id=Creator.Sender_Id;
		
		String IdGrJoinLink="";
		
		
	
		

		
	
	
	
	
    
    
  
    
    
    
    
	
		String url="jdbc:mysql://localhost:3306/SSMP";
		String username="SSMPADMIN";
		String password="SSMPADMIN";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		Connection con=null;
		
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
			
		}
		
		
		
		
		
		try
{
con.setAutoCommit(false);






//1 or more queries or updates

PreparedStatement ps=con.prepareStatement("INSERT INTO GROUPS ( Name,IdGr, Creator, IdGrJoinLink) VALUES (?,?,?,?)");
	ps.setString(1, GroupName);
	ps.setString(2, IdGr);
	ps.setString(3, Creator_Id);
	ps.setString(4, IdGrJoinLink);
	
			
	int number =ps.executeUpdate();

	PreparedStatement ps2=con.prepareStatement("INSERT INTO USER_GROUPS (UserName,IdGr,NameGroup,Category) VALUES (?,?,?,?)");
	ps2.setString(1, Creator_Id);
	ps2.setString(2, IdGr);
	ps2.setString(3, GroupName);
	ps2.setString(4, "Admin");
	
			
	int number2 =ps2.executeUpdate();

	PreparedStatement ps3=con.prepareStatement("INSERT INTO USER_GROUPS (UserName,IdGr,NameGroup,Category) VALUES (?,?,?,?)");
	ps3.setString(1, UserName);
	ps3.setString(2, IdGr);
	ps3.setString(3, Creator.Names);
	ps3.setString(4, "Admin");
	
			
	int number3 =ps3.executeUpdate();




con.commit();


con.setAutoCommit(true);
//  request.setAttribute("Names","${student.Names}" );

//RequestDispatcher rd=request.getRequestDispatcher("beforeLogin.jsp");
//rd.forward(request, response);
response.getWriter().append("OKEY at: ").append(request.getContextPath());


RequestDispatcher rd=request.getRequestDispatcher("Chatting.jsp");
rd.forward(request, response);


}
catch(Exception e)
{
	e.printStackTrace();
	PrintWriter wr=response.getWriter();
	
	wr.println("<p>"+dtf.format(now)+"</p>");
	wr.println("<p style=\"color:red\"> There was a problem while registration  Restar <a href=\"CreateGroup.jsp\">here</a>  </p>");

	
try {
	con.rollback();
} catch (SQLException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}


}
finally
{
	
	
try {
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


}
		
	

		
	
	
		
		
	
	
	
	
	
	
	
	

	
	
	
		
		
		
		doGet(request, response);
	}

}
